import math

assert 1 == 1
assert 1 == 1.0
assert 2.0 == math.sqrt(4)
assert not '1' == 1
assert not 'ciao' == 'Ciao'
