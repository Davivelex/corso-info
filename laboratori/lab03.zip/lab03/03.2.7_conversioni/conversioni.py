CONVERSIONE = {
    'lfl': 30,
    'loz': 33.814,
    'lgal': 0.219969,
    'glb': 0.00220462,
    'min': 39.3701,
    'mft': 3.28084,
    'mmi': 0.00061371
}

metrico = input("Inserisci metrico: ")
imperiale = input("Inserisci imperiale")